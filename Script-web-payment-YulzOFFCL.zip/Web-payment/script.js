function startQRISPayment() {
    // Simulate payment logic for QRIS
    alert("Redirecting to QRIS payment...");
    // You can replace this with actual payment logic
    window.location.href = "payqris.html"; // Change to actual QRIS payment URL
}

function startDanaPayment() {
    // Simulate payment logic for DANA
    alert("Redirecting to DANA payment...");
    // You can replace this with actual payment logic
    window.location.href = "paydana.html"; // Change to actual DANA payment URL
}

function startGopayPayment() {
    // Simulate payment logic for GOPAY
    alert("Redirecting to GOPAY payment...");
    // You can replace this with actual payment logic
    window.location.href = "paygopay.html"; // Change to actual GOPAY payment URL
}

function startOvoPayment() {
    // Simulate payment logic for OVO
    alert("Redirecting to GOPAY payment...");
    // You can replace this with actual payment logic
    window.location.href = "payovo.html"; // Change to actual OVO payment URL
}
